--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: Banco Biblioteca; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Banco Biblioteca";


ALTER SCHEMA "Banco Biblioteca" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: emprestimo; Type: TABLE; Schema: Banco Biblioteca; Owner: postgres
--

CREATE TABLE "Banco Biblioteca".emprestimo (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    horario character varying(20) NOT NULL,
    devolucao character varying(20) NOT NULL,
    quantidade character varying(80) NOT NULL
);


ALTER TABLE "Banco Biblioteca".emprestimo OWNER TO postgres;

--
-- Name: emprestimo_id_seq; Type: SEQUENCE; Schema: Banco Biblioteca; Owner: postgres
--

CREATE SEQUENCE "Banco Biblioteca".emprestimo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "Banco Biblioteca".emprestimo_id_seq OWNER TO postgres;

--
-- Name: emprestimo_id_seq; Type: SEQUENCE OWNED BY; Schema: Banco Biblioteca; Owner: postgres
--

ALTER SEQUENCE "Banco Biblioteca".emprestimo_id_seq OWNED BY "Banco Biblioteca".emprestimo.id;


--
-- Name: livro; Type: TABLE; Schema: Banco Biblioteca; Owner: postgres
--

CREATE TABLE "Banco Biblioteca".livro (
    id integer NOT NULL,
    titulo character varying(255) NOT NULL,
    autor character varying(255) NOT NULL,
    quantidade integer NOT NULL,
    descricao text,
    codigo character varying(100) NOT NULL
);


ALTER TABLE "Banco Biblioteca".livro OWNER TO postgres;

--
-- Name: livro_id_seq; Type: SEQUENCE; Schema: Banco Biblioteca; Owner: postgres
--

CREATE SEQUENCE "Banco Biblioteca".livro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "Banco Biblioteca".livro_id_seq OWNER TO postgres;

--
-- Name: livro_id_seq; Type: SEQUENCE OWNED BY; Schema: Banco Biblioteca; Owner: postgres
--

ALTER SEQUENCE "Banco Biblioteca".livro_id_seq OWNED BY "Banco Biblioteca".livro.id;


--
-- Name: sessao; Type: TABLE; Schema: Banco Biblioteca; Owner: postgres
--

CREATE TABLE "Banco Biblioteca".sessao (
    id integer NOT NULL,
    livro_id integer NOT NULL,
    localizacao integer NOT NULL
);


ALTER TABLE "Banco Biblioteca".sessao OWNER TO postgres;

--
-- Name: sessao_id_seq; Type: SEQUENCE; Schema: Banco Biblioteca; Owner: postgres
--

CREATE SEQUENCE "Banco Biblioteca".sessao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "Banco Biblioteca".sessao_id_seq OWNER TO postgres;

--
-- Name: sessao_id_seq; Type: SEQUENCE OWNED BY; Schema: Banco Biblioteca; Owner: postgres
--

ALTER SEQUENCE "Banco Biblioteca".sessao_id_seq OWNED BY "Banco Biblioteca".sessao.id;


--
-- Name: usuario; Type: TABLE; Schema: Banco Biblioteca; Owner: postgres
--

CREATE TABLE "Banco Biblioteca".usuario (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    endereco character varying(255) NOT NULL,
    telefone character varying(20) NOT NULL,
    matricula character varying(15) NOT NULL
);


ALTER TABLE "Banco Biblioteca".usuario OWNER TO postgres;

--
-- Name: usuario_id_seq; Type: SEQUENCE; Schema: Banco Biblioteca; Owner: postgres
--

CREATE SEQUENCE "Banco Biblioteca".usuario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "Banco Biblioteca".usuario_id_seq OWNER TO postgres;

--
-- Name: usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: Banco Biblioteca; Owner: postgres
--

ALTER SEQUENCE "Banco Biblioteca".usuario_id_seq OWNED BY "Banco Biblioteca".usuario.id;


--
-- Name: emprestimo id; Type: DEFAULT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".emprestimo ALTER COLUMN id SET DEFAULT nextval('"Banco Biblioteca".emprestimo_id_seq'::regclass);


--
-- Name: livro id; Type: DEFAULT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".livro ALTER COLUMN id SET DEFAULT nextval('"Banco Biblioteca".livro_id_seq'::regclass);


--
-- Name: sessao id; Type: DEFAULT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".sessao ALTER COLUMN id SET DEFAULT nextval('"Banco Biblioteca".sessao_id_seq'::regclass);


--
-- Name: usuario id; Type: DEFAULT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".usuario ALTER COLUMN id SET DEFAULT nextval('"Banco Biblioteca".usuario_id_seq'::regclass);


--
-- Data for Name: emprestimo; Type: TABLE DATA; Schema: Banco Biblioteca; Owner: postgres
--

COPY "Banco Biblioteca".emprestimo (id, usuario_id, horario, devolucao, quantidade) FROM stdin;
\.
COPY "Banco Biblioteca".emprestimo (id, usuario_id, horario, devolucao, quantidade) FROM '$$PATH$$/4817.dat';

--
-- Data for Name: livro; Type: TABLE DATA; Schema: Banco Biblioteca; Owner: postgres
--

COPY "Banco Biblioteca".livro (id, titulo, autor, quantidade, descricao, codigo) FROM stdin;
\.
COPY "Banco Biblioteca".livro (id, titulo, autor, quantidade, descricao, codigo) FROM '$$PATH$$/4813.dat';

--
-- Data for Name: sessao; Type: TABLE DATA; Schema: Banco Biblioteca; Owner: postgres
--

COPY "Banco Biblioteca".sessao (id, livro_id, localizacao) FROM stdin;
\.
COPY "Banco Biblioteca".sessao (id, livro_id, localizacao) FROM '$$PATH$$/4815.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: Banco Biblioteca; Owner: postgres
--

COPY "Banco Biblioteca".usuario (id, nome, email, endereco, telefone, matricula) FROM stdin;
\.
COPY "Banco Biblioteca".usuario (id, nome, email, endereco, telefone, matricula) FROM '$$PATH$$/4811.dat';

--
-- Name: emprestimo_id_seq; Type: SEQUENCE SET; Schema: Banco Biblioteca; Owner: postgres
--

SELECT pg_catalog.setval('"Banco Biblioteca".emprestimo_id_seq', 10, true);


--
-- Name: livro_id_seq; Type: SEQUENCE SET; Schema: Banco Biblioteca; Owner: postgres
--

SELECT pg_catalog.setval('"Banco Biblioteca".livro_id_seq', 5, true);


--
-- Name: sessao_id_seq; Type: SEQUENCE SET; Schema: Banco Biblioteca; Owner: postgres
--

SELECT pg_catalog.setval('"Banco Biblioteca".sessao_id_seq', 10, true);


--
-- Name: usuario_id_seq; Type: SEQUENCE SET; Schema: Banco Biblioteca; Owner: postgres
--

SELECT pg_catalog.setval('"Banco Biblioteca".usuario_id_seq', 6, true);


--
-- Name: emprestimo emprestimo_pkey; Type: CONSTRAINT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".emprestimo
    ADD CONSTRAINT emprestimo_pkey PRIMARY KEY (id);


--
-- Name: livro livro_pkey; Type: CONSTRAINT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".livro
    ADD CONSTRAINT livro_pkey PRIMARY KEY (id);


--
-- Name: sessao sessao_pkey; Type: CONSTRAINT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".sessao
    ADD CONSTRAINT sessao_pkey PRIMARY KEY (id);


--
-- Name: usuario usuario_email_key; Type: CONSTRAINT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".usuario
    ADD CONSTRAINT usuario_email_key UNIQUE (email);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: emprestimo emprestimo_usuario_id_fkey; Type: FK CONSTRAINT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".emprestimo
    ADD CONSTRAINT emprestimo_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES "Banco Biblioteca".usuario(id);


--
-- Name: sessao sessao_livro_id_fkey; Type: FK CONSTRAINT; Schema: Banco Biblioteca; Owner: postgres
--

ALTER TABLE ONLY "Banco Biblioteca".sessao
    ADD CONSTRAINT sessao_livro_id_fkey FOREIGN KEY (livro_id) REFERENCES "Banco Biblioteca".livro(id);


--
-- PostgreSQL database dump complete
--

